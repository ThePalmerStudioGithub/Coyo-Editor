﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coyo
{
    // Code written by: Blaine Palmer
    // Website:https://thepalmerstudio.net
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
       
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
 
        }

        private void code_Tick(object sender, EventArgs e)
        {
       
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Does the action of the text boxes with if statements \\
            if (textBox1.Text == "//")
            {
                // Displays notification and makes sure that the notification is set up for another command
                notifyIcon1.BalloonTipText = "Enter your comment with  the // picked up.";
                notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
                notifyIcon1.ShowBalloonTip(5000);
            }
            else if (textBox2.Text == "//")
            {
                // Displays notification and makes sure that the notification is set up for another command
                notifyIcon1.BalloonTipText = "Enter your comment with  the // picked up.";
                notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
                notifyIcon1.ShowBalloonTip(5000);
               
            }
            if (textBox1.Text == "run:" + "show notification with text:Hello World")
            {
                // Displays notification and makes sure that the notification is set up for another command
                notifyIcon1.BalloonTipText = "Hello World";
                notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
                notifyIcon1.ShowBalloonTip(5000);
          

            }
            else if (textBox2.Text == "run:" + "show notification with text:Hello World")
            {
                // Displays notification and makes sure that the notification is set up for another command
                notifyIcon1.BalloonTipText = "Hello World";
                notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
                notifyIcon1.ShowBalloonTip(5000);


            }
            if(textBox1.Text == "show notification with the time")
            {
                notifyIcon1.BalloonTipText = "The current time is:" + DateTime.Now;
                notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
                notifyIcon1.ShowBalloonTip(5000);
            }
            else if(textBox2.Text == "show notification with the time")
            {
                notifyIcon1.BalloonTipText = "The current time is:" + DateTime.Now;
                notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
                notifyIcon1.ShowBalloonTip(5000);
            }
            else
            {
                // Displays notification and makes sure that the notification is set up for another command
                notifyIcon1.BalloonTipText = "Oops!! There's nothing in your code." + "Check the text fields:" + " " + textBox1.Name + " " + "and" + " " + textBox2.Name +  "and try entering some valid code this time." + "Please😊😂👌👌😉😉😎";
                notifyIcon1.BalloonTipIcon = ToolTipIcon.Error;
                notifyIcon1.ShowBalloonTip(5000);
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
